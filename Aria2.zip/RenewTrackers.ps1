# aria2.conf位置、要下载的trackers文件，在这里修改
$ConfigFile = "aria2.conf"
$TrackersFile = "trackers_best_ip.txt"
$DownloadLink = "https://ngosang.github.io/trackerslist/$TrackersFile"

Invoke-WebRequest -Uri $DownloadLink -OutFile $env:TEMP\$TrackersFile

$TrackersStream = (Get-Content $env:TEMP\$TrackersFile -Raw).Replace("`n`n", ",").Insert(0, "bt-tracker=")
$TrackersStream = $TrackersStream.Substring(0, $TrackersStream.Length - 1)

$ExcludeLineNum=(Select-String -Path $ConfigFile -SimpleMatch "bt-tracker=").LineNumber
$ConfigStream = Get-Content $ConfigFile -Encoding UTF8
$ConfigStream[$ExcludeLineNum-1]=$TrackersStream
Set-Content -Path $ConfigFile -Value $ConfigStream -Encoding UTF8

Remove-Item -Path $env:TEMP\trackers*